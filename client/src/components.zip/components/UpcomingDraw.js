import { useState } from 'react';
import React from 'react'
import LotteryCard from './UpcomingLotteryCard'
import axios from 'axios';

function UpcomingDraw({isMenuOpen}) {

    const [upcomingDraw, setUpcomingDraw] = useState(null);
    const fetchData = async () => {
        try {
            const response = await axios.get('https://bc.game/api/platform-lottery/lottery-info/list-upcoming', {
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0',
                    'Cookie': 'smidV2=202410010243140e5a09af083eb0ce6bfcd553c705b917004b332066d6aabe0; _gcl_au=1.1.491419327.1727775803; _ga=GA1.1.118626875.1727775808; rtgio_tid=v1.0.15745976804.12114693723; blueID=9ea6d3b4-9c0e-4e07-a2b1-f60424e92a3a; invitation-alias-code=4cxse6dr; invitation-url=https%3A%2F%2Fbc.game%2Fi-4cxse6dr-n%2F%3Fp%3D%252F%26stag%3D69000_66fda9bc81ae9e237ec9076a; invitation-view-id=1811834568384190893; slfps=a61a07529a69e235fcbabaf860a89f6de3fc1efb855aa20722a11495387d9218; _hjSessionUser_3056635=eyJpZCI6ImEzMTU1NTY5LTE3NTktNWQ5OS05MGNmLTc4YjNlOThkZjg5ZCIsImNyZWF0ZWQiOjE3Mjc4MTA1MDk1ODgsImV4aXN0aW5nIjp0cnVlfQ==; SESSION=01kwmivqeddnpp1925474fcb18741fa2ce0ee088b469ecfd2b; _ga_7Q8ZMQJCT2=GS1.1.1728063036.5.1.1728064747.60.0.0; g_state={"i_l":0}; intercom-session-t87ss9s4=eWhrUzcvOE5nVUF1ejBSenYwdHBGTWdEL25OVXlhZDJFeThBc29MT3FISjN4dFo4YTVpWkdJdWFDNjlyMHhxcS0tUFNZc2tTRkJPT04xMzdMUi9oZ1BzQT09--57bbcd2e11774d7a252b925e1df441cd9584d2bc; intercom-device-id-t87ss9s4=48b5823a-e0f1-46c6-90b4-96eba8873485; JSESSIONID=OTBlMTc2NjctY2I4Yy00NTc3LWE2MzUtMTE2Y2M1OGRmZGRl; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%2254049055%22%2C%22first_id%22%3A%22192477670ed4d7-08ba4228e02f328-26001151-921600-192477670eee26%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E5%BC%95%E8%8D%90%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC%22%2C%22%24latest_referrer%22%3A%22https%3A%2F%2Fbc.game%2Fgame%2Fcrash%22%2C%22%24latest_utm_source%22%3A%224cxse6dr%22%2C%22_latest_stag%22%3A%2290655_66fb4f43b877b5d70f437ebb%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMTkyNDc3NjcwZWQ0ZDctMDhiYTQyMjhlMDJmMzI4LTI2MDAxMTUxLTkyMTYwMC0xOTI0Nzc2NzBlZWUyNiIsIiRpZGVudGl0eV9sb2dpbl9pZCI6IjU0MDQ5MDU1In0%3D%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%24identity_login_id%22%2C%22value%22%3A%2254049055%22%7D%2C%22%24device_id%22%3A%22192477670ed4d7-08ba4228e02f328-26001151-921600-192477670eee26%22%7D; visit-url=https%3A%2F%2Fbc.game%2Flottery; __cf_bm=0QNOJBT8wkWTKfT_sEIBmRR8EeGg2bmo5brDvhlzito-1728100826-1.0.1.1-mJwgFuk8QU2.9AmDJ4yaw.BNLOJuickaqQvgc08lRWSMS2Y44SefeH4pe8vK9QDeH2PeSVoiDaaxjPtScOB8AA; _ga_B23BPN2TGE=GS1.1.1728159185.31.0.1728159185.0.0.0; .thumbcache_1f3830c3848041ef5612f684078f2210=Z0GH1Mqy5hxuexL2qdk5rJVm7n9m2a+dESv6BXVkkKJ80hT2JLBhE+bf4WqziUfvFEq5BSJIYdQfGBHu7a70LA%3D%3D'
                }
            });
            console.log(response.data);
        } catch (error) {
            console.error("Error fetching data:", error.message);
        }
    };

    fetchData();

    return (
        <div className={`${isMenuOpen ? '' : 'show-'}upcoming-draw`}>
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
            <LotteryCard />
        </div>
    )
}

export default UpcomingDraw;