import React from 'react'
import PopularLotteryCard from './PopularLotteryCard';

function PopularDraw({isMenuOpen}) {
  return (
    <div className={`${isMenuOpen ? '' : 'show-'}popular-draw`}>
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
        <PopularLotteryCard />
    </div>
  )
}

export default PopularDraw;