import React from 'react'

function LotteryCard({ country = "fr" }) {
  return (
    <div className='size-full'>
      <div className='size-full'>
        <section className='lottery-card'>
          <div className='flag-container'>
            <section className='card-flag'>
              <img className='flag-img' src={`https://hatscripts.github.io/circle-flags/flags/${country}.svg`} alt="" />
            </section>
          </div>
          <div className='lottery-address'>FAST KENO 20/80</div>
          <div className='lottery-price'>$3,000.00</div>
          <div className='card-divider' />
          <div className='timer-title'>Next Draw Starts in</div>
          <div className='align-center full-width'>
            <div className='lottery-timer'>
              <span>00h</span> : <span>00m</span> : <span>00s</span>
            </div>
            <div className='btn-bet'> Bet Now</div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default LotteryCard;