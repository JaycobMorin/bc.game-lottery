import React from 'react'
import GameItem from './GameItem'

function Navbar({isMenuOpen}) {

    const navItems = [
        { icon: '/assets/img/svg_1.svg', title: 'Casino' },
        { icon: '/assets/img/svg_2.svg', title: 'Item 2' },
        { icon: '/assets/img/svg_3.svg', title: 'Item 3' },
        { icon: '/assets/img/svg_4.svg', title: 'Item 4' }
    ]

    return (
        <div>
            <nav className={`main-menu ${isMenuOpen ? "show" : ""}`}>
                <ul>
                    {navItems.map((item, index) => (
                        <GameItem 
                        key={index} 
                        icon={`${process.env.PUBLIC_URL}${item.icon}`} 
                        title={item.title}
                        isMenuOpen={isMenuOpen}
                      />
                    ))}
                </ul>
            </nav>
        </div>
    )
}

export default Navbar