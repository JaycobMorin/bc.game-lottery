import React from 'react'

function LatestResultsItem({ country = 'fr' }) {
    return (
        <>
            <tr className='latest-results-item'>
                <td style={{paddingLeft: '1rem'}}>
                    <div className='latest-results-name'>
                        <img className='top-winning-flag' src={`https://hatscripts.github.io/circle-flags/flags/${country}.svg`} alt="" />
                        <section className='latest-results-info'>
                            <h5 className='latest-results-address'>Slovakia EKlub Keno 20/80</h5>
                            <p className='latest-results-time'>06/10/2024, 13:16:00</p>
                        </section>
                    </div>
                </td>
                <td style={{textAlign:'left'}}>
                    <section className='latest-results-jackpot'>
                        <span className='latest-results-ball'>2</span>
                    </section>
                </td>
                <td className='latest-results-bet'>
                    <section className='latest-results-bet-caption'>
                        <label>BET NOW</label>
                    </section>
                </td>
            </tr>
        </>
    )
}

export default LatestResultsItem