import React from 'react'
import LatestResultsItem from './LatestResultsItem';

function LatestResults() {
  return (
    <div className='latest-results-box'>
        <table style={{width: '100%'}}>
            <thead>
                <tr className='latest-results-head'>
                    <th className='latest-results-caption-1'>Lottery Name</th>
                    <th className='latest-results-caption-2'>
                        <div style={{width: '100%'}}>Jackpot Number</div>
                    </th>
                </tr>
            </thead>
            <tbody>
                    <LatestResultsItem />
                    <LatestResultsItem />
                    <LatestResultsItem />
                    <LatestResultsItem />
                    <LatestResultsItem />
                    <LatestResultsItem />
                    <LatestResultsItem />
                    <LatestResultsItem />
                    <LatestResultsItem />
                    <LatestResultsItem />
                    <LatestResultsItem />
            </tbody>
        </table>
        <div>
            <button></button>
            <div>
                <input type="text" name="" id="" />
                <span></span>
                <div><span></span></div>
            </div>
            <button></button>
        </div>
    </div>
  )
}

export default LatestResults;